# Relativistic Beaming Simulation

## Overview
This script computes **relativistic Doppler beaming curves** integrated over photometric passbands.  
It supports multiple spectrum formats (ATLAS9, PHOENIX, TMAP, USER ASCII) and filter sets (e.g., SDSS, Gaia, Kepler, TESS, Bessell).

Main features:
- Relativistic Doppler shift (`doppler_shift`)
- Energy-counting vs. photon-counting detector response (`phot_E`, `phot_P`)
- Foreground extinction correction (Fitzpatrick+19, via `dust_extinction`)
- Spectrum readers for common stellar atmosphere grids
- Filter transmission curve loading (`ReadFilter`)
- Beaming factor calculation with linear-fit diagnostics (`factor`)
- Quick-look plotting of spectra and passbands

A built-in **smoke test** uses a flat spectrum with the SDSS g-band to generate example plots.

---

## Requirements
- Python ≥ 3.8 (works with `importlib_resources` fallback for older versions)
- Dependencies:
  - `numpy`
  - `scipy`
  - `matplotlib`
  - `astropy`
  - `dust_extinction`

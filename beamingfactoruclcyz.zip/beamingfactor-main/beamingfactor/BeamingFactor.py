# -*- coding: utf-8 -*-

# --- Monkey-patch: make older Python environments expose importlib.resources.files()
#     Some older environments have the backport package `importlib_resources` instead
#     of the stdlib `importlib.resources`. The two are API-compatible for our usage.
#     We alias the backport as if it were the stdlib module so downstream code that
#     calls `importlib.resources.files(...)` continues to work.
import sys
import importlib_resources
sys.modules['importlib.resources'] = importlib_resources

# --- Actual imports below ---
#     Note: This script depends on scientific Python stack components:
#       - numpy/scipy for arrays and interpolation
#       - matplotlib for plotting
#       - astropy (units, FITS I/O)
#       - dust_extinction for extinction laws (Fitzpatrick+19)
#     Ensure these are installed in your environment.
import os
import astropy
import scipy
import numpy as np
import matplotlib.pyplot as plt  # plotting backend (line charts, etc.)
import dust_extinction
from beamingfactor import BeamingFactor as bf  # Optional: not required by this script
import importlib_resources as ilr

# If you need to directly use importlib.resources.files(...) for data location
# (e.g., locating packaged data files within the dust_extinction package),
# we keep a convenience path handle here:
ref = ilr.files("dust_extinction") / "data"


def doppler_shift(miu, Vorb, vr):
    """
    Special-relativistic Doppler shift for frequency-like arrays.

    Parameters
    ----------
    miu : array-like
        Input frequencies (Hz) *or* any frequency-proportional quantity to be
        transformed by the Doppler factor. In this code path, we indeed pass
        frequency arrays.
    Vorb : float
        Orbital speed (km/s). Used for the transverse/special-relativistic term.
    vr : float
        Radial velocity (km/s). Positive for recession (redshift), negative for
        approach (blueshift).

    Returns
    -------
    array-like
        Doppler-shifted frequencies with the relativistic factor applied:
        ν' = ν * sqrt(1 - β_orb^2) / (1 + β_r), where β ≡ v/c.

    Notes
    -----
    - c is taken as 2.99792e5 km/s (speed of light).
    - This form captures both time dilation (via Vorb) and the longitudinal
      Doppler effect (via vr). For small velocities (|v| << c), it reduces
      approximately to the classical shift.
    """
    c = 2.99792e5  # km/s
    return miu * np.sqrt(1 - Vorb**2 / c**2) / (1 + vr / c)


def phot_E(Vorb, vr, Fre, Hnu, WL, Wl, Wr, PB_curve, ebv):
    """
    Compute beaming-weighted flux for an energy-counting detector.

    This integrates the spectral energy density through the filter curve,
    applying a relativistic beaming (Doppler) factor and foreground extinction.

    Parameters
    ----------
    Vorb : float
        Orbital speed (km/s).
    vr : float
        Radial velocity (km/s).
    Fre : array-like
        Frequency grid (Hz) corresponding to the input spectrum.
    Hnu : array-like
        Spectral energy density in "per-frequency" form used by this pipeline
        (see construction in `factor()`), such that
        F_lambda is reconstructed as 4 * Hnu * c / (1/f)^2 * D^3 below.
        Units are internally consistent but not explicitly enforced.
    WL : array-like
        Wavelength grid (Å) for performing the integration across the passband.
    Wl, Wr : float
        Lower/upper wavelength bounds (Å) of the passband (not directly used;
        WL already spans the evaluation range).
    PB_curve : array-like
        Filter throughput evaluated on WL (dimensionless, 0–1 typically).
    ebv : float
        E(B–V) color excess for dust reddening. We use Rv=3.1 below.

    Returns
    -------
    float
        Scalar integrated, extinction-attenuated, passband-weighted energy flux.

    Notes
    -----
    - We use Fitzpatrick (2019) extinction law (F19) with Rv=3.1 via
      dust_extinction.parameter_averages.F19.
    - We construct F_lambda (per Å) from the pipeline's Hnu and Doppler factor.
    - For an energy-counting detector, the passband integral is
      ∫ T(λ) * F_λ(λ) dλ (discrete sum here).
    """
    from astropy import units as u
    from dust_extinction.parameter_averages import F19
    from scipy import interpolate
    ext = F19(Rv=3.1)
    c = 2.99792e5

    # Doppler-shift frequency grid and convert to wavelength in Å.
    # Conversion: λ[Å] = (c[km/s] / ν[Hz]) * 1e13 (since 1 km = 1e13 Å).
    fre = doppler_shift(Fre, Vorb, vr)
    wave = c / fre * 1e13  # Å

    # Relativistic Doppler/beaming factor D:
    # D = sqrt(1 - β_orb^2) / (1 + β_r)
    D = np.sqrt(1 - Vorb**2 / c**2) / (1 + vr / c)

    # Convert to F_lambda using this pipeline's chosen relation:
    # flamda ≡ F_λ ∝ 4 * Hnu * c / (1/f)^2 * D^3
    # This matches the internal data representation used below.
    flamda = 4 * Hnu * c / (1 / fre)**2 * D**3

    # Interpolate F_λ from (wave, flamda) to evaluation grid (WL).
    f_sp = interpolate.interp1d(
        wave, flamda, kind='quadratic',
        bounds_error=False, fill_value="extrapolate"
    )

    # Guard against minor extrapolation artifacts by clipping WL to data range.
    WL_clip = np.clip(WL, wave.min(), wave.max())

    # Apply Milky Way-like extinction curve to F_λ(λ): A_V = R_V * E(B−V).
    flux = f_sp(WL_clip) * ext.extinguish(WL_clip * u.AA, Av=ebv * 3.1)

    # Energy-counting integral: sum(T(λ) * F_λ(λ) * dλ). Here dλ is absorbed
    # into the uniform grid step at construction; we keep proportional sums.
    return np.sum(flux * PB_curve)


def phot_P(Vorb, vr, Fre, Hnu, WL, Wl, Wr, PB_curve, ebv):
    """
    Compute beaming-weighted flux for a photon-counting detector.

    Similar to `phot_E`, but uses photon-counting weighting: T(λ) * F_λ(λ) * λ,
    reflecting that photon rate ∝ energy flux times λ (since E_ph ∝ 1/λ).

    Parameters
    ----------
    (Same as phot_E.)

    Returns
    -------
    float
        Scalar integrated, extinction-attenuated, passband-weighted photon flux.

    Notes
    -----
    - For photon-counting systems (e.g., many CCD/CMOS detectors in suitable
      regimes), the effective bandpass weighting introduces an extra λ factor.
    - Implementation detail: we compute ∑ T(λ) * F_λ(λ) * λ on a uniform λ grid.
    """
    from astropy import units as u
    from dust_extinction.parameter_averages import F19
    from scipy import interpolate
    ext = F19(Rv=3.1)
    c = 2.99792e5

    fre = doppler_shift(Fre, Vorb, vr)
    wave = c / fre * 1e13  # Å
    D = np.sqrt(1 - Vorb**2 / c**2) / (1 + vr / c)
    flamda = 4 * Hnu * c / (1 / fre)**2 * D**3

    f_sp = interpolate.interp1d(
        wave, flamda, kind='quadratic',
        bounds_error=False, fill_value="extrapolate"
    )
    WL_clip = np.clip(WL, wave.min(), wave.max())
    flux = f_sp(WL_clip) * ext.extinguish(WL_clip * u.AA, Av=ebv * 3.1)

    # Photon-counting weighting: multiply by λ.
    return np.sum(flux * PB_curve * WL_clip)


def Linear(x, k, b):
    # Simple first-order linear model used by curve_fit in `factor()`:
    # y = k * x + b
    return x * k + b


def To_Air(wave):
    r"""
    Convert wavelengths from VACUUM to AIR (input/output in Å).

    Reference
    ---------
    Morton (2003), "Atomic Data for Resonance Absorption Lines", PASP 115, 203.
    (URL in the original code: https://iopscience.iop.org/article/10.1086/377639/pdf)

    Parameters
    ----------
    wave : array-like
        Vacuum wavelengths in Å.

    Returns
    -------
    array-like
        Air wavelengths in Å.

    Notes
    -----
    The conversion uses a standard refractive index formula parameterized in
    terms of wavenumber (σ = 1e4 / λ[Å]).
    """
    sig = 1.0e4 / wave
    return wave / (
        1
        + 8.06051e-5
        + 2.480990e-2 / (132.274 - sig**2)
        + (1.74557e-4 / (39.32957 - sig**2))
    )


def ReadSpec(specfile=None, spectype=None):
    """
    Read a local stellar/SED spectrum file.

    Supported types
    ---------------
    - 'ATLAS9'  : ATLAS9 text grids (expects specific columns)
    - 'PHOENIX' : PHOENIX FITS spectra (wavelength from fixed path; flux from file)
    - 'TMAP'    : TMAP ASCII spectra (skip comment lines beginning with '*')
    - 'USER'    : Generic ASCII (two columns: wavelength[Å], flux)

    Examples
    --------
    ReadSpec(specfile='.../fp05hep02t40000g45k2odfnew.dat', spectype='ATLAS9')

    Physics note
    ------------
    For ATLAS9, code reconstructs F_lambda via
    F_lambda = 4 * Hnu * c / wavelength^2 (consistent with pipeline usage).
    This preserves internal consistency with the rest of the script.

    Returns
    -------
    (wave, flux) : tuple of np.ndarray
        Wavelengths in Å and corresponding flux values (arbitrary units consistent
        with the rest of the pipeline).

    Raises
    ------
    KeyError           : for missing file or unsupported spectype.
    FileNotFoundError  : when `specfile` path does not exist.
    """
    c = 2.99792e5
    if specfile is None:
        raise KeyError('Undefined name of spectral file')
    if not os.path.exists(specfile):
        raise FileNotFoundError(f"File Not Found: '{specfile}'")
    if spectype not in ['ATLAS9', 'PHOENIX', 'TMAP', 'USER']:
        raise KeyError(
            "Undefined type of '{specfile}', please define with spectype={'ATLAS9','PHOENIX','TMAP','USER'}"
        )

    if spectype == 'ATLAS9':
        # Expected format: a fixed-column ASCII with wavelengths (nm) and Hnu-like
        # values. We convert nm→Å and reconstruct flux per Å as used downstream.
        data = open(specfile, 'r').readlines()
        wave, hnu = [], []
        for row in data[2:-5]:
            tem = row.split()
            wave.append(float(tem[2]) * 10)  # nm -> Å
            hnu.append(float(tem[4]))
        wave = np.array(wave)
        hnu = np.array(hnu)
        flux = 4 * hnu * c / wave**2
        return wave, flux

    if spectype == 'PHOENIX':
        # PHOENIX: wavelength grid is common and shipped separately; flux array
        # is read from the provided FITS file.
        from astropy.io import fits
        fpath = os.path.join(os.path.dirname(__file__), 'WAVE_PHOENIX-ACES-AGSS-COND-2011.fits')
        wave = fits.open(fpath)[0].data
        flux = fits.open(specfile)[0].data
        return wave, flux

    if spectype == 'TMAP':
        # TMAP ASCII: skip empty lines and comments starting with '*'.
        data = open(specfile, 'r').readlines()
        wave, flux = [], []
        for row in data:
            if not row or row[0] == '*':
                continue
            parts = row.strip().split()
            if len(parts) < 2:
                continue
            wave.append(float(parts[0]))
            flux.append(float(parts[1]))
        return np.array(wave), np.array(flux)

    if spectype == 'USER':
        # Generic two-column ASCII (optionally with a leading '#' header line).
        data = open(specfile, 'r').readlines()
        sign = 1 if data[0].startswith('#') else 0
        wave = np.array([float(i.rstrip('\n').split()[0]) for i in data[sign:]])
        flux = np.array([float(i.rstrip('\n').split()[1]) for i in data[sign:]])
        return wave, flux


def plot_spec(WAVE, FLUX, PB_x, Trans):
    """
    Quick-look plot: normalized spectrum segment vs. normalized passband.

    Parameters
    ----------
    WAVE, FLUX : array-like
        Full input spectrum (Å, flux).
    PB_x, Trans : array-like
        Passband wavelength grid and throughput.

    Notes
    -----
    - Both curves are normalized to their respective maxima for shape comparison.
    - The axes are log-scaled to highlight shapes over wide dynamic ranges.
    """
    INDEX = (WAVE > PB_x.min()) & (WAVE < PB_x.max())
    W = WAVE[INDEX]
    F = FLUX[INDEX]
    plt.plot(W, F / np.max(F))
    plt.plot(PB_x, Trans / np.max(Trans))
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel("Wavelength (Å)")
    plt.ylabel("Normalized (arb.)")
    plt.show()


def ReadFilter(band, bandfile, bandtype):
    """
    Load a photometric filter passband.

    Parameters
    ----------
    band : str
        Filter name. Supported built-ins:
        u, g, r, i, z, TESS, G, Gbp, Grp, U, B, V, R, I, kepler, NUV_CSST,
        u_c, g_c, r_c, i_c, z_c, y_c, USER
        - For built-in names, the function looks up a file under ./PassBandFile/.
        - For 'USER', you must provide `bandfile`.
    bandfile : str or None
        Path to a user-supplied passband file (two columns: λ[Å], throughput).
        Required when `band == 'USER'`. Ignored for built-ins.
    bandtype : str
        'P' (photon-counting) or 'E' (energy-counting).
        For built-ins, this will be inferred from the filename extension (.P/.E)
        and override the input `bandtype`.

    Returns
    -------
    (wave, trans, bandtype) : tuple
        Passband wavelength grid (Å), throughput array (0–1), and final bandtype.

    Raises
    ------
    KeyError : for unsupported band name or missing bandfile in USER mode.

    Notes
    -----
    - Built-in mapping is defined by LOG below.
    - The passband files are expected to be whitespace-separated two-column ASCII.
    - For built-ins, the function infers photon/energy mode from the file suffix.
    """
    if band is None:
        raise KeyError('Undefined filter passband.')
    LOG = {
        'u': 'SLOAN_SDSS.u.dat.P',
        'g': 'SLOAN_SDSS.g.dat.P',
        'r': 'SLOAN_SDSS.r.dat.P',
        'i': 'SLOAN_SDSS.i.dat.P',
        'z': 'SLOAN_SDSS.z.dat.P',
        'TESS': 'TESS_TESS.Red.dat.E',
        'G': 'GAIA_GAIA3.G.dat.P',
        'Gbp': 'GAIA_GAIA3.Gbp.dat.P',
        'Grp': 'GAIA_GAIA3.Grp.dat.P',
        'U': 'Generic_Bessell.U.dat.E',
        'B': 'Generic_Bessell.B.dat.E',
        'V': 'Generic_Bessell.V.dat.E',
        'R': 'Generic_Bessell.R.dat.E',
        'I': 'Generic_Bessell.I.dat.E',
        'kepler': 'Kepler_Kepler.K.dat.P',
        'NUV_CSST': 'NUV_throughput.txt.P',
        'u_c': 'u_throughput.txt.P',
        'g_c': 'g_throughput.txt.P',
        'r_c': 'r_throughput.txt.P',
        'i_c': 'i_throughput.txt.P',
        'z_c': 'z_throughput.txt.P',
        'y_c': 'y_throughput.txt.P',
        'USER': None
    }
    if band not in LOG:
        raise KeyError(f'Unsupported filter name: {band}')
    if band == 'USER':
        if bandfile is None:
            raise KeyError('Undefined bandfile for USER band.')
        data = open(bandfile, 'r').readlines()
        # USER: do not override bandtype; we honor the caller's input here.
    else:
        # Built-in: locate under ./PassBandFile and infer P/E from filename suffix.
        fpath = os.path.join(os.path.dirname(__file__), 'PassBandFile', LOG[band])
        data = open(fpath, 'r').readlines()
        bandtype = LOG[band].split('.')[-1]  # 'P' or 'E'

    # Parse two-column ASCII; optional leading comment line starting with '#'.
    sign = 1 if data[0].startswith('#') else 0
    wave = np.array([float(i.rstrip('\n').split()[0]) for i in data[sign:]])
    trans = np.array([float(i.rstrip('\n').split()[1]) for i in data[sign:]])
    return wave, trans, bandtype


def factor(
    specfile=None, spectype=None, showspec=False, convert_air=False,
    band=None, bandfile=None, bandtype='E',
    RV_min=None, RV_max=None, K=None, V0=0, e=0, omega=0, ebv=0,
    Constant_Factor=True, Dindex=None, plot_beaming=False
):
    """
    Compute the relativistic beaming curve integrated over a given passband.

    This is the main driver that:
      1) reads the input spectrum (ASCII or model grids),
      2) reads the filter transmission curve,
      3) applies Doppler/beaming + extinction,
      4) integrates over the passband (energy- or photon-counting),
      5) normalizes and (optionally) fits a linear trend vs. radial velocity.

    Inputs
    ------
    specfile : str
        Path to spectrum file. For 'USER', an ASCII two-column file (λ[Å], flux).
    spectype : {'ATLAS9','PHOENIX','TMAP','USER'}
        Spectrum format selector; see `ReadSpec()` for details.
    showspec : bool
        If True, calls `plot_spec` to visualize spectrum vs. passband.
    convert_air : bool
        If True, convert spectrum wavelengths from vacuum to air using `To_Air`.
    band : str
        Filter name; built-ins listed in `ReadFilter`. Use 'USER' with `bandfile`.
    bandfile : str or None
        Custom passband file for 'USER' mode (λ[Å], throughput).
    bandtype : {'P','E'}
        Photon-counting ('P') vs. energy-counting ('E'). For built-ins this is
        overridden based on the filename suffix.
    RV_min, RV_max : float or None
        Radial velocity bounds (km/s). If unspecified, they are inferred from
        K, V0, e, omega as: [V0 - K + e*cos(ω), V0 + K + e*cos(ω)].
    K : float or None
        Semi-amplitude (km/s). Used to auto-derive [RV_min, RV_max] if needed.
    V0 : float
        Systemic velocity (km/s).
    e : float
        Eccentricity used only in the RV range heuristic above.
    omega : float
        Argument of periastron in degrees; used only in the RV range heuristic.
    ebv : float
        Color excess E(B−V) for extinction; we adopt Rv=3.1.
    Constant_Factor : bool
        If True, assume a constant beaming factor and fit a linear relation to
        normalized flux vs. velocity, returning the slope in km/s. If False,
        return a numerical derivative instead (centered finite difference).
    Dindex : None or list of floats
        If None, compute default deviation percentages at 1%, 2%, 5% of dynamic
        range from the best-fit line. If a list is provided, compute at those
        thresholds instead.
    plot_beaming : bool
        Unused here (placeholder for potential plotting within the function).

    Returns
    -------
    Constant_Factor == True:
        slope_km_s : float
            Slope in km/s (note the sign convention applied downstream).
        DINDEX or DINDEX_list : list of floats
            Percentage of RV samples deviating from the linear fit by more than
            1%, 2%, 5% (or user-provided thresholds).
        K_use : array
            Array of RV sample points (km/s) excluding the normalization anchor.
        f_obs : array
            Normalized flux values at K_use (unitless, f/f_ref).
    Constant_Factor == False:
        K_use_center : array
            Centered RV points (km/s) corresponding to the derivative estimate.
        deriv : array
            Numerical derivative (converted to km/s scaling) of the beaming curve.

    Implementation Details
    ----------------------
    - We interpolate the passband to a uniform WL grid with step=0.005 Å.
      This effectively absorbs dλ into uniform sampling for ∑ T(λ)*F(λ) weighting.
    - Frequency and energy density arrays are constructed from the spectrum
      segment overlapping the passband (expanded by ±100 Å).
    - The Doppler/beaming factor D^3 is applied as per relativistic boosting.
    """
    from scipy import interpolate
    from scipy.optimize import curve_fit

    c = 2.99792e5
    WAVE, FLUX = ReadSpec(specfile=specfile, spectype=spectype)
    PB_x, Trans, bandtype = ReadFilter(band, bandfile, bandtype)

    # Construct a dense wavelength grid WL across the passband for integration.
    # Note: using endpoint=False avoids hitting the upper boundary exactly,
    # which can reduce edge effects in some interpolations.
    step = 0.005
    n = int((PB_x.max() - PB_x.min()) / step)
    WL = np.linspace(PB_x.min(), PB_x.max(), n, endpoint=False)

    # Interpolate throughput to WL (quadratic for smooth passband shapes).
    f_t = interpolate.interp1d(PB_x, Trans, kind='quadratic', bounds_error=False, fill_value="extrapolate")
    WP = f_t(WL)

    # Restrict the spectrum to a window slightly larger than the passband
    # to ensure robust interpolation near edges.
    INDEX0 = (WAVE > PB_x.min() - 100) & (WAVE < PB_x.max() + 100)
    wave0 = WAVE[INDEX0]
    flux0 = FLUX[INDEX0]

    if convert_air:
        wave0 = To_Air(wave0)

    if showspec:
        plot_spec(WAVE, FLUX, PB_x, Trans)

    # Determine RV sampling range.
    if RV_min is None or RV_max is None:
        if K is not None:
            RV_min = V0 - K + e * np.cos(omega / 180 * np.pi)
            RV_max = V0 + K + e * np.cos(omega / 180 * np.pi)
        else:
            raise KeyError('Radial Velocity range not defined!')

    # Build the RV grid K_arr. If Constant_Factor is True, we reserve one
    # additional point (0) for normalization; otherwise we pad on both sides
    # for centered differences.
    if Constant_Factor:
        if RV_max - RV_min >= 250:
            K_arr = np.append(np.arange(RV_min, RV_max, 2.5), [0])
        else:
            K_arr = np.append(np.arange(RV_min, RV_max, (RV_max - RV_min) / 100), [0])
        length = len(K_arr) - 1
    else:
        if RV_max - RV_min >= 250:
            K_arr = np.append(np.arange(RV_min - 2.5, RV_max + 2.5, 2.5), [0])
        else:
            K_arr = np.append(
                np.arange(RV_min - (RV_max - RV_min) / 100,
                          RV_max + (RV_max - RV_min) / 100 + 1e-8,
                          (RV_max - RV_min) / 100),
                [0]
            )
        length = len(K_arr) - 2

    # Construct frequency grid from wavelength and build the pipeline's Hnu:
    #   Fre [Hz] = c[km/s]*1e3 / (λ[m]) = c / (λ[Å]/1e10) * 1e3
    #              (the code uses c*1e3 / (wave0/1e10))
    #   Hnu is calculated to be consistent with the F_lambda reconstruction in
    #   phot_E/phot_P. Units are kept internally consistent.
    Fre = c * 1e3 / (wave0 / 1e10)      # Hz
    Hnu = flux0 / 4 / c * (1 / Fre)**2  # Consistent with downstream reconstruction

    # Integrate observed flux across the passband (P vs E detector response).
    if bandtype == 'E':
        f_obs = np.array([phot_E(i, i, Fre, Hnu, WL, PB_x.min(), PB_x.max(), WP, ebv) for i in K_arr])
    elif bandtype == 'P':
        f_obs = np.array([phot_P(i, i, Fre, Hnu, WL, PB_x.min(), PB_x.max(), WP, ebv) for i in K_arr])
    else:
        raise KeyError(f'Unsupported Filter type: {bandtype}')

    # Normalize by the value at the anchor (last element), then drop the anchor
    # so we return arrays aligned with the RV samples only.
    f_obs = f_obs[:-1] / f_obs[-1]
    K_use = K_arr[:-1]

    if Constant_Factor:
        # Fit a straight line to normalized flux vs. RV and measure deviations
        # from linearity as a simple non-linearity diagnostic (DINDEX).
        popt, pcov = curve_fit(Linear, K_use, f_obs)
        diff = float(np.max(f_obs) - np.min(f_obs))
        slope_km_s = -1.0 * popt[0] * c  # Convert to km/s convention

        if Dindex is None:
            INDEX1 = np.abs(f_obs - Linear(K_use, *popt)) > 1 / 100 * diff
            INDEX2 = np.abs(f_obs - Linear(K_use, *popt)) > 2 / 100 * diff
            INDEX5 = np.abs(f_obs - Linear(K_use, *popt)) > 5 / 100 * diff
            DINDEX = [len(K_use[INDEX1]) / length * 100,
                      len(K_use[INDEX2]) / length * 100,
                      len(K_use[INDEX5]) / length * 100]
            return slope_km_s, DINDEX, K_use, f_obs
        else:
            DINDEX_list = []
            for dth in Dindex:
                mask = np.abs(f_obs - Linear(K_use, *popt)) > dth / 100 * diff
                DINDEX_list.append(len(K_use[mask]) / length * 100)
            return slope_km_s, DINDEX_list, K_use, f_obs
    else:
        # Non-constant factor mode: return a finite-difference derivative
        # (centered) scaled by c to km/s units.
        deriv = -1.0 * (f_obs[2:] - f_obs[:-2]) / (2 * np.mean(np.diff(K_use))) * c
        return K_use[1:-1], deriv


if __name__ == "__main__":
    import time, os, numpy as np
    import matplotlib.pyplot as plt

    # =========================================================
    # Option A: use your own spectrum file (two columns: wavelength[Å], flux)
    # Option B: if you don’t have one, generate a flat spectrum automatically
    # =========================================================
    # This block either generates a simple flat spectrum (for smoke tests)
    # or uses a user-specified spectrum file. The downstream pipeline expects
    # wavelengths in Å and a flux column in arbitrary units (self-consistent).
    use_fake_spectrum = True
    outdir = "plots"
    os.makedirs(outdir, exist_ok=True)

    if use_fake_spectrum:
        # Generate a flat spectrum over 3000–11000 Å with unit flux.
        specfile = os.path.join(outdir, "flat_spectrum.txt")
        if not os.path.exists(specfile):
            wave = np.linspace(3000.0, 11000.0, 20000)  # Å
            flux = np.ones_like(wave)
            with open(specfile, "w") as f:
                for w, fl in zip(wave, flux):
                    f.write(f"{w:.3f} {fl:.6e}\n")
        spectype = "USER"
    else:
        # Replace with your own ASCII (λ[Å], flux) spectrum path.
        specfile = "/path/to/your/spectrum.txt"  # replace with your spectrum
        spectype = "USER"

    # ======= Single filter: SDSS g (.P) =======
    # We compute the beaming curve using the built-in SDSS g passband:
    #   - band="g" auto-loads PassBandFile/SLOAN_SDSS.g.dat.P
    #   - bandtype="P" indicates photon-counting (also inferred from file suffix)
    #   - K=100 sets the semi-amplitude used to determine the default RV range
    t0 = time.time()
    slope_g, _, K_g, f_g = factor(
        specfile=specfile,
        spectype=spectype,
        band="g",      # automatically loads PassBandFile/SLOAN_SDSS.g.dat.P
        bandtype="P",
        K=100,
        showspec=False
    )
    t1 = time.time()

    # Linear fit post-processing
    # Convert the returned slope (km/s) into a dimensionless slope k_hat by
    # dividing by c, then compute intercept b_hat using mean residual closure.
    c_kms = 2.99792e5
    k_hat = -slope_g / c_kms
    b_hat = (f_g - k_hat * K_g).mean()
    fit_g = k_hat * K_g + b_hat
    res_g = f_g - fit_g

    # Beaming curve + linear fit plot
    plt.figure()
    plt.plot(K_g, f_g, "o", label="data")
    plt.plot(K_g, fit_g, "-", label=f"linear fit (slope={k_hat:.3e})")
    plt.xlabel("Radial Velocity (km/s)")
    plt.ylabel("Normalized Beaming Flux")
    plt.title("Beaming Curve + Linear Fit (SDSS g, P)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "beaming_fit_g.png"), dpi=200)

    # Residuals plot
    plt.figure()
    plt.axhline(0, ls="--", lw=1)
    plt.plot(K_g, res_g, ".", ms=4)
    plt.xlabel("Radial Velocity (km/s)")
    plt.ylabel("Residual")
    plt.title("Residuals (SDSS g, P)")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "beaming_residual_g.png"), dpi=200)

    print(f"[g] factor() runtime: {t1 - t0:.4f} seconds")
    print(f"Plots saved to: {os.path.abspath(outdir)}")

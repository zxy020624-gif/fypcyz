import numpy as np
import matplotlib.pyplot as plt

# ----- set your path (relative or absolute) -----
path = "../beamingfactor/PassBandFile/SLOAN_SDSS.g.dat.P"

# Load the two numeric columns (skip commented lines starting with '#')
# We don't rely on header names; we just take the first two columns.
data = np.loadtxt(path, comments="#")

# First column: wavelength; second column: transmission
wave = data[:, 0]
trans = data[:, 1]

# Plot
plt.figure(figsize=(8, 5))
plt.plot(wave, trans, linewidth=1.5)

plt.title("Sloan SDSS g-band Filter Transmission Curve")
plt.xlabel("WaveAns.")          # change to 'nm' if your file is in nm
plt.ylabel("Transmission")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

